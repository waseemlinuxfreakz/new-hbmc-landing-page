import "./Preloader.css";
import { Cube } from "react-preloaders";

const Preloader = () => {
  return <Cube />;
};

export default Preloader;
